//
//  photos_CollectionViewCell.swift
//  Car Repair Shop
//
//  Created by DTIMac13 on 21/08/18.
//  Copyright © 2018 DTIMac13. All rights reserved.
//

import UIKit

class photos_CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var car_images: UIImageView!
    
    func configurecell(image: UIImage){
        
        imageView?.image = image
        
    }
}
