//
//  Log_in_ViewController.swift
//  Car Repair Shop
//
//  Created by DTIMac13 on 20/08/18.
//  Copyright © 2018 DTIMac13. All rights reserved.
//

import UIKit

class Log_in_ViewController: UIViewController {

    @IBOutlet weak var logo: UIImageView!
    
    @IBOutlet weak var remember_button: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func remb_button(_ sender: Any) {
        remember_button.isSelected = !remember_button.isSelected
    }


}
