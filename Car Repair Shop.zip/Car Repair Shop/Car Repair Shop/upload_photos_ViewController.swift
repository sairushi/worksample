//
//  upload_photos_ViewController.swift
//  Car Repair Shop
//
//  Created by DTIMac13 on 21/08/18.
//  Copyright © 2018 DTIMac13. All rights reserved.
//

import UIKit

class upload_photos_ViewController: UIViewController,UINavigationControllerDelegate,UIImagePickerControllerDelegate {
  
    var imagePicker = UIImagePickerController()
    @IBOutlet weak var take_from_camera: UIButton!
    @IBOutlet weak var pick_from_library: UIButton!
    @IBOutlet weak var cancel_button: UIButton!
    @IBAction func cancel_Button(_ sender: Any) {
        self.view.removeFromSuperview()
    }
    override func viewDidLoad() {
        imagePicker.delegate = self
        super.viewDidLoad()
    }
    
    @IBAction func take_from_camera(_ sender: Any) {
        imagePicker.allowsEditing = false
        imagePicker.sourceType = .savedPhotosAlbum
        self.present(imagePicker, animated: true, completion: nil)
    }
    @objc func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        imagePicker.dismiss(animated: true, completion: nil)
        let choose_image = info[UIImagePickerControllerOriginalImage] as! UIImage
        imageView?.image = choose_image
        self.view.removeFromSuperview()
    }
    
    @IBAction func picr_from_Lbr(_ sender: Any) {
       imagePicker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        imagePicker.allowsEditing = false
        imagePicker.sourceType = .photoLibrary
        self.present(imagePicker, animated: true, completion: nil)
    }
}
