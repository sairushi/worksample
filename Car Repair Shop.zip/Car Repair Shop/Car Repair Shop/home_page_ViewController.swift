//
//  home_page_ViewController.swift
//  Car Repair Shop
//
//  Created by DTIMac13 on 21/08/18.
//  Copyright © 2018 DTIMac13. All rights reserved.
//

import UIKit
var imagesArray = [UIImage]()
  var imageView: UIImageView?
class home_page_ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UICollectionViewDelegate,UICollectionViewDataSource {

   
    @IBAction func submit_button(_ sender: Any) {
        let alert = UIAlertController(title: "Thanks for submisson", message: "We will get back with repair estimates", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
            switch action.style{
            case .default:
                print("default")
                
            case .cancel:
                print("cancel")
                
            case .destructive:
                print("destructive")
                
                
            }}))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    @IBOutlet weak var CollectionView: UICollectionView!
    var photos: upload_photos_ViewController!
    override func viewDidLoad() {
        super.viewDidLoad()
    photos = self.storyboard?.instantiateViewController(withIdentifier: "images_upload") as! upload_photos_ViewController
    }

//    @IBAction func upload_photos(_ sender: Any) {
//        photo_uploads()
//
//    }

    func photo_uploads(){
        UIView.animate(withDuration: 0.4) {() -> Void in
            self.photos?.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
            self.photos.view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
            self.addChildViewController(self.photos!)
            self.view.addSubview((self.photos?.view)!)
        }
    }
    
    
    @IBAction func getImagesAction(_ sender: Any) {
            photo_uploads()
   
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if let pickedimage = (info[UIImagePickerControllerOriginalImage] as? UIImage){
            imagesArray = [pickedimage]
            
        }
        CollectionView.reloadData()
         self.view.removeFromSuperview()
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imagesArray.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! photos_CollectionViewCell
        cell.configurecell(image: imagesArray[indexPath.row])
        cell.car_images.image = imagesArray[indexPath.row]
        return cell
        
    }

    
//    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        return image_array.count
//    }
//
//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! photos_CollectionViewCell
////        imageView = cell.viewWithTag(11) as? UIImageView
//        let image = imageView?.image
//        image_array.append(image!)
//        cell.car_images.image = image_array[indexPath.row]
//        return cell
//    }
    
    
    
    
    
    
    
    
    
    
    
}
